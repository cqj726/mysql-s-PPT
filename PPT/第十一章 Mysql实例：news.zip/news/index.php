<!doctype html>
<htm|>

<head>
    <meta charset="utf-8"/>
    <title>访客留言表</title>
    <script TYPE="text/javascript">
        function check_data()
        {
            if (document.myForm.author.value.length==0)
                alert("作者字段不可以空白哦！");
            else
                if(document.myForm.content.value.length==0)
                    alert("内容字段不可以空白哦！");
                else
                    myForm.submit();
        }
    </script>
</head>

<body bgcolor='#24ACF2'>

<div width="70%" style='background-color:#ddd; align:center;padding:20px;overflow:auto; height:450px;'>

<?php

    //指定每页显示几行记录
    $Records_per_page = 5;

    //显示第几页的记录
    if (isset($_GET["page"]))
        $page = $_GET["page"];
    else
        $page =1;

    //建立数据连接
    $link=mysqli_connect("localhost","root","root","message");

	mysqli_query($link,"set character set 'utf8'");//读库
	mysqli_query($link,"set names 'utf8'");//写库


    //执行SQL命令，按降序日期方式排序
    $sql = "SELECT * FROM info ORDER BY mdate DESC";

    $result = $link->query($sql);

    echo "<table width=80% align=center cellspacing=2>";

    //显示记录
    $j = 1;
    while ($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
    {
    echo "<tr bgcolor='#D9D9FF'>";
    echo "<td style='padding:10px;border-width:2px;border-color:#FFF222;border-style:solid;'>作者：".$row["author"]." &nbsp;&nbsp;&nbsp;&nbsp;";
    echo "主题：".$row["subjects"]." &nbsp;&nbsp;&nbsp;&nbsp; ";
    echo "时间：".$row["mdate"]."<br>---------------------------------------------------------------------<br>";
    echo $row["content"]."<br><br><br></td></tr>";
    $j++;
    }

    echo "</table>";

    //释放内存空间
    mysqli_free_result($result);
    mysqli_close($link);
?>

</div><br/>

<form name="myForm" method="post" action="transmit.php">
<table border="0" width="60%" align="center" cellspacing="0">
<tr bgcolor="#0084CA" align="center">
    <td colspan="2">
    <font color="#FFFFFF">请在此输入新的留言</font></td>
</tr>
<tr>
    <td width="25%">作者</td>
    <td width="75%">
        <input name="author" type="text" size="50">
    </td>
</tr>

<tr bgcolor="#84D7FF">
    <td width="25%">主题</td>
    <td width="75%"><input name="subjects" type="text" size="50"></td>
</tr>

<tr bgcolor="#D9F2FF">
    <td width="25%">内容</td>
    <td width="75%">
        <textarea name="content" cols="80" rows="5"></textarea>
    </td>
</tr>

<tr>
    <td colspan="2" align="center">
        <input type="button" value="张贴" onClick="check_data()">
        <input type="reset" value="重输">
    </td>
</tr>

</table>
</form>


</body >
</html >
