create database message；

use message;

CREATE TABLE info (
  id INT PRIMARY KEY AUTO_INCREMENT,
  author VARCHAR (20) NOT NULL,
  subjects TINYTEXT,
  content TEXT NOT NULL,
  mdate DATETIME NOT NULL
);

