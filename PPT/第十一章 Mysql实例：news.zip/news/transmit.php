<?php
$author=$_POST["author"];
$subjects=$_POST["subjects"];
$content=$_POST["content"];
$current_time=date("y-m-d H:i:S");

//建立数据连接
$link = mysqli_connect("localhost","root","root","message");

mysqli_query($link,"set character set 'utf8'");//读库
mysqli_query($link,"set names 'utf8'");//写库

//执行SQL命令，将作者，主题，内容和日期添加到info数据表中
$sql="INSERT INTO info(author,subjects,content,mdate) VALUES('$author','$subjects','$content','$current_time')";

mysqli_query($link,$sql);

//关闭数据连接
Mysqli_close($link);
//将网页重定向到 index.php
header("location:index.php");
exit();
?>